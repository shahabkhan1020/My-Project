const songs = [
  {
    name: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    title: "Dreamscape",
    artist: "SoundHelix",
    cover: "https://source.unsplash.com/300x300?guitar",
  },
  {
    name: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    title: "Ocean Waves",
    artist: "HelixTune",
    cover: "https://source.unsplash.com/300x300?ocean",
  },
  {
    name: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    title: "Morning Sun",
    artist: "AudioWorld",
    cover: "https://source.unsplash.com/300x300?sunrise",
  },
];

const audio = document.getElementById("audio");
const playBtn = document.getElementById("play");
const prevBtn = document.getElementById("prev");
const nextBtn = document.getElementById("next");
const progress = document.getElementById("progress");
const progressContainer = document.getElementById("progress-container");
const currentTimeEl = document.getElementById("current-time");
const durationEl = document.getElementById("duration");
const volume = document.getElementById("volume");
const title = document.getElementById("title");
const artist = document.getElementById("artist");
const cover = document.getElementById("cover");
const playlistEl = document.getElementById("playlist");

let songIndex = 0;
let isPlaying = false;

function loadSong(song) {
  title.textContent = song.title;
  artist.textContent = song.artist;
  cover.src = song.cover;
  audio.src = song.name;
  updatePlaylistUI();
}

function playSong() {
  isPlaying = true;
  playBtn.innerHTML = '<i class="fa fa-pause"></i>';
  audio.play();
}

function pauseSong() {
  isPlaying = false;
  playBtn.innerHTML = '<i class="fa fa-play"></i>';
  audio.pause();
}

playBtn.addEventListener("click", () => {
  isPlaying ? pauseSong() : playSong();
});

function prevSong() {
  songIndex = (songIndex - 1 + songs.length) % songs.length;
  loadSong(songs[songIndex]);
  playSong();
}

function nextSong() {
  songIndex = (songIndex + 1) % songs.length;
  loadSong(songs[songIndex]);
  playSong();
}

audio.addEventListener("timeupdate", updateProgress);

function updateProgress(e) {
  const { duration, currentTime } = e.srcElement;
  const progressPercent = (currentTime / duration) * 100;
  progress.style.width = `${progressPercent}%`;

  const currentMin = Math.floor(currentTime / 60);
  const currentSec = Math.floor(currentTime % 60);
  const durationMin = Math.floor(duration / 60);
  const durationSec = Math.floor(duration % 60);
  if (duration) {
    currentTimeEl.textContent = `${currentMin}:${currentSec < 10 ? "0" : ""}${currentSec}`;
    durationEl.textContent = `${durationMin}:${durationSec < 10 ? "0" : ""}${durationSec}`;
  }
}

progressContainer.addEventListener("click", (e) => {
  const width = progressContainer.clientWidth;
  const clickX = e.offsetX;
  const duration = audio.duration;
  audio.currentTime = (clickX / width) * duration;
});

volume.addEventListener("input", () => {
  audio.volume = volume.value;
});

audio.addEventListener("ended", nextSong);
prevBtn.addEventListener("click", prevSong);
nextBtn.addEventListener("click", nextSong);

function createPlaylist() {
  playlistEl.innerHTML = "";
  songs.forEach((song, index) => {
    const li = document.createElement("li");
    li.textContent = `${song.title} — ${song.artist}`;
    li.addEventListener("click", () => {
      songIndex = index;
      loadSong(song);
      playSong();
    });
    playlistEl.appendChild(li);
  });
}

function updatePlaylistUI() {
  const items = playlistEl.querySelectorAll("li");
  items.forEach((li, i) => {
    li.classList.toggle("active", i === songIndex);
  });
}

createPlaylist();
loadSong(songs[songIndex]);
